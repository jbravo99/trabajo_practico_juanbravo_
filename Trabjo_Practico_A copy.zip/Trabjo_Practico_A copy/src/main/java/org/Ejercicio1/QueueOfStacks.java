package org.Ejercicio1;

class QueueOfStacks {
    private int n; // Tamaño de la matriz
    private Pila[] pilas; // Array de pilas

    public QueueOfStacks(int n) {
        this.n = n;
        pilas = new Pila[n];
        for (int i = 0; i < n; i++) {
            pilas[i] = new Pila(n);
        }
    }

    public void enqueue(int elemento) {
        int pilaIndex = 0;
        while (!pilas[pilaIndex].isEmpty()) {
            pilaIndex++;
        }
        pilas[pilaIndex].push(elemento);
    }

    public int dequeue() {
        int elemento = pilas[0].pop();
        for (int i = 1; i < n; i++) {
            if (!pilas[i].isEmpty()) {
                pilas[i - 1].push(pilas[i].pop());
            }
        }
        return elemento;
    }

    public int getTrace() {
        int trace = 0;
        for (int i = 0; i < n; i++) {
            if (!pilas[i].isEmpty()) {
                trace += pilas[i].peek();
            }
        }
        return trace;
    }

    public QueueOfStacks getTranspose() {
        QueueOfStacks transpose = new QueueOfStacks(n);
        for (int i = 0; i < n; i++) {
            while (!pilas[i].isEmpty()) {
                transpose.enqueue(pilas[i].pop());
            }
        }
        return transpose;
    }

    public static QueueOfStacks matrixSum(QueueOfStacks queue1, QueueOfStacks queue2) {
        QueueOfStacks sum = new QueueOfStacks(queue1.n);
        for (int i = 0; i < queue1.n; i++) {
            Pila pila1 = queue1.pilas[i];
            Pila pila2 = queue2.pilas[i];
            Pila sumPila = sum.pilas[i];
            while (!pila1.isEmpty()) {
                int elemento1 = pila1.pop();
                int elemento2 = pila2.pop();
                sumPila.push(elemento1 + elemento2);
            }
        }
        return sum;
    }
}