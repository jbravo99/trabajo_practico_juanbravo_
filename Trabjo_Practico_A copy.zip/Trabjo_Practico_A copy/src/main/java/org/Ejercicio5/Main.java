package org.Ejercicio5;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Stack stack = new Stack();
        // Agregar elementos a la pila desordenada
        stack.add(5);
        stack.add(2);
        stack.add(8);
        stack.add(2);
        stack.add(3);
        stack.add(5);

        // Generar una nueva pila sin elementos repetidos y ordenados
        Stack newStack = generateNewStack(stack);

        // Imprimir la nueva pila
        while (!newStack.isEmpty()) {
            System.out.println(newStack.getTop());
            newStack.remove();
        }
    }

    public static Stack generateNewStack(Stack stack) {
        Set<Integer> set = new HashSet<>();
        while (!stack.isEmpty()) {
            set.add(stack.getTop());
            stack.remove();
        }
        List<Integer> list = new ArrayList<>(set);
        Collections.sort(list);

        Stack newStack = new Stack();
        for (int i : list) {
            newStack.add(i);
        }

        return newStack;
    }
}

