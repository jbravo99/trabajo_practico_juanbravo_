package org.Ejercicio5.Montecarlo;

public class RegionCuadrada {
    private double lado;

    public RegionCuadrada(double lado) {
        this.lado = lado;
    }

    public boolean contieneCoordenada(Coordenada coordenada) {
        return coordenada.getX() >= 0 && coordenada.getX() <= lado &&
                coordenada.getY() >= 0 && coordenada.getY() <= lado;
    }
}
