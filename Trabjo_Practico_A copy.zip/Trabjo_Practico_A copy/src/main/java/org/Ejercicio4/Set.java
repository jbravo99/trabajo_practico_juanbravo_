package org.Ejercicio4;

import java.util.Arrays;
import java.util.Random;

public class Set implements ISet {

    private final int[] array;
    private int count;

    private Set(Builder builder) {
        this.array = builder.array;
        this.count = builder.count;
    }

    @Override
    public void add(int a) {
        for (int i = 0; i < this.count; i++) {
            if (this.array[i] == a) {
                return;
            }
        }

        this.array[this.count] = a;
        this.count++;
    }

    @Override
    public void remove(int a) {
        for (int i = 0; i < this.count; i++) {
            if (this.array[i] == a) {
                if (i == this.count - 1) {
                    this.count--;
                    return;
                }
                this.array[i] = this.array[this.count - 1];
                this.count--;
            }
        }
    }

    @Override
    public boolean isEmpty() {
        return this.count == 0;
    }

    @Override
    public int choose() {
        if (this.count == 0) {
            System.out.println("No se puede elegir un elemento del conjunto vacio");
            return -1;
        }
        int randomIndex = (new Random()).nextInt(this.count);
        return this.array[randomIndex];
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Set set = (Set) o;
        if (count != set.count) return false;

        for (int i = 0; i < count; i++) {
            if (array[i] != set.array[i]) {
                return false;
            }
        }
        return true;
    }

    public static class Builder {
        private int[] array;
        private int count;

        public Builder() {
            this.array = new int[10000];
            this.count = 0;
        }

        public Builder add(int a) {
            for (int i = 0; i < this.count; i++) {
                if (this.array[i] == a) {
                    return this;
                }
            }

            this.array[this.count] = a;
            this.count++;
            return this;
        }

        public Builder addAll(Set set) {
            for (int i = 0; i < set.count; i++) {
                this.add(set.array[i]);
            }
            return this;
        }

        public Set build() {
            return new Set(this);
        }
    }
}
