package org.Ejercicio3;

public class QueueOfQueue<T> {
    private static class Node<T> {
        T data;
        Node<T> next;

        Node(T data) {
            this.data = data;
        }
    }

    private static class Queue<T> {
        //referencia al primer nodo de cola (NodeOfQueue),
        // mientras que tailOfQueue es una referencia al último nodo de cola
        private Node<T> head;
        private Node<T> tail;

        boolean isEmpty() {
            return head == null;
        }

        void enqueue(T data) {
            Node<T> newNode = new Node<>(data);
            if (isEmpty()) {
                head = newNode;
                tail = newNode;
            } else {
                tail.next = newNode;
                tail = newNode;
            }
        }

        T dequeue() {
            if (isEmpty()) {
                throw new IllegalStateException("Queue is empty");
            }
            T data = head.data;
            head = head.next;
            if (head == null) {
                tail = null;
            }
            return data;
        }
    }

    private static class NodeOfQueue<T> {
        Queue<T> queue;
        NodeOfQueue<T> next;

        NodeOfQueue(Queue<T> queue) {
            this.queue = queue;
        }
    }

    private NodeOfQueue<T> headOfQueue;
    private NodeOfQueue<T> tailOfQueue;

    public void enqueue(Queue<T> queue) {
        NodeOfQueue<T> newNodeOfQueue = new NodeOfQueue<>(queue);
        if (isEmpty()) {
            headOfQueue = newNodeOfQueue;
            tailOfQueue = newNodeOfQueue;
        } else {
            tailOfQueue.next = newNodeOfQueue;
            tailOfQueue = newNodeOfQueue;
        }
    }

    public Queue<T> dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("QueueOfQueue is empty");
        }
        Queue<T> queue = headOfQueue.queue;
        headOfQueue = headOfQueue.next;
        if (headOfQueue == null) {
            tailOfQueue = null;
        }
        return queue;
    }

    public boolean isEmpty() {
        return headOfQueue == null;
    }

    public int size() {
        int count = 0;
        NodeOfQueue<T> current = headOfQueue;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public void concatenar(QueueOfQueue<T>... queues) {
        QueueOfQueue<T> result = new QueueOfQueue<>();

        for (QueueOfQueue<T> queue : queues) {
            while (!queue.isEmpty()) {
                Queue<T> nestedQueue = queue.dequeue();
                result.enqueue(nestedQueue);
            }
        }

        headOfQueue = result.headOfQueue;
        tailOfQueue = result.tailOfQueue;
    }

    //Crea una nueva instancia de Queue a partir de la instancia de QueueOfQueue,
    // colocando todos los elementos de las colas internas en una sola cola
    public Queue<T> flat() {
        Queue<T> result = new Queue<>();

        while (!isEmpty()) {
            Queue<T> nestedQueue = dequeue();
            while (!nestedQueue.isEmpty()) {
                result.enqueue(nestedQueue.dequeue());
            }
        }

        return result;
    }

    //Crea una nueva instancia de QueueOfQueue y vacía las colas internas en orden inverso
    public void revertir() {
        QueueOfQueue<T> result = new QueueOfQueue<>();

        while (!isEmpty()) {
            Queue<T> nestedQueue = dequeue();
            Queue<T> reversedNestedQueue = new Queue<>();

            while (!nestedQueue.isEmpty()) {
                reversedNestedQueue.enqueue(nestedQueue.dequeue());
            }

            result.enqueue(reversedNestedQueue);
        }

        headOfQueue = result.headOfQueue;
        tailOfQueue = result.tailOfQueue;
    }
}

