package org.Ejercicio2;

public class Main {
    public static void main(String[] args) {
        // Ejemplo de uso de las estructuras y funciones

        // Invertir un Stack genérico
        Stack<Integer> stack = new Stack<>();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        System.out.println("Stack original: " + stack);
        stack.reverse();
        System.out.println("Stack invertido: " + stack);

        // Copiar un Set genérico
        Set<String> set = new Set<>();
        set.add("apple");
        set.add("banana");
        set.add("orange");
        System.out.println("Set original: " + set);
        Set<String> copySet = set.copy();
        System.out.println("Copia del set: " + copySet);
    }
}