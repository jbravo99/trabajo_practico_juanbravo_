package org.Ejercicio5.Montecarlo;

import java.util.ArrayList;
import java.util.List;

public class Montecarlo {
    private List<Coordenada> coordenadas;

    public Montecarlo() {
        coordenadas = new ArrayList<>();
    }

    public void agregarCoordenada(Coordenada coordenada) {
        coordenadas.add(coordenada);
    }

    public int getCantidadCoordenadas() {
        return coordenadas.size();
    }

    public double aproximarPi() {
        int puntosDentroCirculo = 0;
        int puntosTotales = coordenadas.size();

        for (Coordenada coordenada : coordenadas) {
            double x = coordenada.getX();
            double y = coordenada.getY();

            if (x * x + y * y <= 1) {
                puntosDentroCirculo++;
            }
        }

        return 4.0 * puntosDentroCirculo / puntosTotales;
    }
}

