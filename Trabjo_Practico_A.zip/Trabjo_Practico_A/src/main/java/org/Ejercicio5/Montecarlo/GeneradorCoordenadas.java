package org.Ejercicio5.Montecarlo;

import java.util.Random;

public class GeneradorCoordenadas {
    public static void main(String[] args) {
        Montecarlo montecarlo = new Montecarlo();
        Random random = new Random();

        while (montecarlo.getCantidadCoordenadas() < 1000) {
            double x = random.nextDouble();
            double y = random.nextDouble();

            Coordenada coordenada = new Coordenada(x, y);
            montecarlo.agregarCoordenada(coordenada);
        }

        double aproximacionPi = montecarlo.aproximarPi();
        System.out.println("Aproximación de Pi: " + aproximacionPi);
    }
}
