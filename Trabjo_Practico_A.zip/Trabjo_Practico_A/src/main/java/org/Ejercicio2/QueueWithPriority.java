package org.Ejercicio2;

import java.util.PriorityQueue;

// Implementación de Queue con prioridad genérico
class QueueWithPriority<T> {
    private PriorityQueue<T> queue;

    public QueueWithPriority() {
        queue = new PriorityQueue<>();
    }

    public void enqueue(T element) {
        queue.add(element);
    }

    public T dequeue() {
        return queue.remove();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }
}