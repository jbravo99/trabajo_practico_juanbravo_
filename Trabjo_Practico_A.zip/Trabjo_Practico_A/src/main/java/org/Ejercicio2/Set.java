package org.Ejercicio2;

import java.util.HashSet;

// Implementación de Set genérico
class Set<T> {
    private HashSet<T> set;

    public Set() {
        set = new HashSet<>();
    }

    public void add(T element) {
        set.add(element);
    }

    public void remove(T element) {
        set.remove(element);
    }

    public boolean contains(T element) {
        return set.contains(element);
    }

    public int size() {
        return set.size();
    }

    // Función para copiar un Set genérico
    public Set<T> copy() {
        Set<T> copySet = new Set<>();
        copySet.set.addAll(this.set);
        return copySet;
    }
}