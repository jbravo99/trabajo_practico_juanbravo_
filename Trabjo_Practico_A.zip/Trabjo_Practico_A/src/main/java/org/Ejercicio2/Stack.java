package org.Ejercicio2;

import java.util.ArrayDeque;
import java.util.Deque;

// Implementación de Stack genérico
class Stack<T> {
    private Deque<T> stack;

    public Stack() {
        stack = new ArrayDeque<>();
    }

    public void push(T element) {
        stack.push(element);
    }

    public T pop() {
        return stack.pop();
    }

    public boolean isEmpty() {
        return stack.isEmpty();
    }

    // Función para invertir los elementos del Stack
    public void reverse() {
        Deque<T> reversedStack = new ArrayDeque<>();
        while (!stack.isEmpty()) {
            reversedStack.push(stack.pop());
        }
        stack = reversedStack;
    }
}