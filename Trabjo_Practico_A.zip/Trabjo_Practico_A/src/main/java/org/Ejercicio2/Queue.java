package org.Ejercicio2;

import java.util.ArrayDeque;
import java.util.Deque;

// Implementación de Queue genérico
class Queue<T> {
    private Deque<T> queue;

    public Queue() {
        queue = new ArrayDeque<>();
    }

    public void enqueue(T element) {
        queue.addLast(element);
    }

    public T dequeue() {
        return queue.removeFirst();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }
}