package org.Ejercicio1;

class Pila {
    private int[] elementos;
    private int tamaño;
    private int tope;

    public Pila(int tamaño) {
        this.tamaño = tamaño;
        elementos = new int[tamaño];
        tope = -1;
    }

    public boolean isEmpty() {
        return tope == -1;
    }

    public void push(int elemento) {
        if (tope < tamaño - 1) {
            tope++;
            elementos[tope] = elemento;
        } else {
            System.out.println("La pila está llena");
        }
    }

    public int pop() {
        if (!isEmpty()) {
            int elemento = elementos[tope];
            tope--;
            return elemento;
        } else {
            System.out.println("La pila está vacía");
            return -1;
        }
    }

    public int peek() {
        if (!isEmpty()) {
            return elementos[tope];
        } else {
            System.out.println("La pila está vacía");
            return -1;
        }
    }
}
