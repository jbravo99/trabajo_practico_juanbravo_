package org.Ejercicio6.b;

//Se agregaron dos métodos adicionales al TDA Set:
//
//isSubset(Set otherSet): Este método recibe otra instancia de Set y verifica si el conjunto actual es un subconjunto
//de ese otro conjunto. Itera sobre los elementos del otro conjunto y verifica si cada elemento existe en el conjunto
//actual. Si encuentra algún elemento que no existe en el conjunto actual, devuelve false; de lo contrario,
//devuelve true.
//
//complement(): Este método calcula el conjunto complemento del conjunto actual. Antes de calcular el complemento,
// verifica si el conjunto actual es un subconjunto de sí mismo. Si no es así, muestra un mensaje de error y
// devuelve null. Luego, itera sobre todos los elementos posibles y agrega aquellos que no existen en el conjunto
// actual en una nueva instancia de Set, que se devuelve como el conjunto complemento.
import java.util.Random;

public class Set {

    private final int[] array;
    private int count;

    public Set() {
        this.array = new int[10000];
        this.count = 0;
    }

    public void add(int a) {
        for (int i = 0; i < this.count; i++) {
            if (this.array[i] == a) {
                return;
            }
        }

        this.array[this.count] = a;
        this.count++;
    }

    public void remove(int a) {
        for (int i = 0; i < this.count; i++) {
            if (this.array[i] == a) {
                if (i == this.count - 1) {
                    this.count--;
                    return;
                }
                this.array[i] = this.array[this.count - 1];
                this.count--;
            }
        }
    }

    public boolean isEmpty() {
        return this.count == 0;
    }

    public int choose() {
        if (this.count == 0) {
            System.out.println("No se puede elegir un elemento del conjunto vacío");
            return -1;
        }
        int randomIndex = (new Random()).nextInt(this.count);
        return this.array[randomIndex];
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Set set = (Set) o;
        if (count != set.count) return false;

        for (int i = 0; i < count; i++) {
            if (array[i] != set.array[i]) {
                return false;
            }
        }
        return true;
    }

    public boolean isSubset(Set otherSet) {
        for (int i = 0; i < otherSet.count; i++) {
            boolean found = false;
            for (int j = 0; j < this.count; j++) {
                if (this.array[j] == otherSet.array[i]) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    public Set complement() {
        if (!isSubset(this)) {
            System.out.println("No se puede calcular el complemento de un conjunto que no es subconjunto del superconjunto.");
            return null;
        }
        Set complementSet = new Set();
        for (int i = 0; i < this.array.length; i++) {
            boolean found = false;
            for (int j = 0; j < this.count; j++) {
                if (this.array[j] == i) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                complementSet.add(i);
            }
        }
        return complementSet;
    }
}

