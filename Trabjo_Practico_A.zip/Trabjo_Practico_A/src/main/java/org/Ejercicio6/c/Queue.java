package org.Ejercicio6.c;

//Se agregs ls propiedad last que hace referencia al último nodo de la cola
public class Queue implements IQueue {

    private Node first;
    private Node last;

    public class Node {
        private int value;
        private Node previous;
        private Node next;

        public Node(int value, Node previous, Node next) {
            this.value = value;
            this.previous = previous;
            this.next = next;
        }

        public int getValue() {
            return value;
        }

        public Node getPrevious() {
            return previous;
        }

        public Node getNext() {
            return next;
        }

        public void setPrevious(Node previous) {
            this.previous = previous;
        }

        public void setNext(Node next) {
            this.next = next;
        }
    }


    //En el método add, verifico si la cola está vacía y, si es así,
    // actualiza tanto first como last para que apunten al nuevo nodo
    @Override
    public void add(int a) {
        Node node = new Node(a, null, null);
        if (isEmpty()) {
            this.first = node;
            this.last = node;
        } else {
            node.setPrevious(this.last);
            this.last.setNext(node);
            this.last = node;
        }
    }

    //verifico si la cola está vacía y si first y last apuntan al mismo nodo.
    @Override
    public void remove() {
        if (isEmpty()) {
            System.out.println("No se puede desacolar una cola vacía");
            return;
        }
        if (this.first == this.last) {
            this.first = null;
            this.last = null;
        } else {
            this.first = this.first.getNext();
            this.first.setPrevious(null);
        }
    }

    @Override
    public boolean isEmpty() {
        return this.first == null;
    }

    @Override
    public int getFirst() {
        if (isEmpty()) {
            System.out.println("No se puede obtener el primero de una cola vacía");
            return -1;
        }
        return this.first.getValue();
    }
}

