package org.Ejercicio6.a;

//agrega una variable capacity para almacenar la capacidad máxima de la pila
// y una variable size para llevar el control del número de elementos actuales en la pila
public class LimitedStack implements ILimitedStack {

    private Node first;
    private int capacity;
    private int size;

    public LimitedStack(int capacity) {
        this.capacity = capacity;
        this.size = 0;
    }


    @Override
    public void add(int a) {
        if (size >= capacity) {
            System.out.println("No se puede agregar más elementos. La pila está llena.");
            return;
        }
        this.first = new Node(a, this.first);
        size++;
    }

    @Override
    public void remove() {
        if (this.first == null) {
            System.out.println("No se puede desapilar una pila vacía.");
            return;
        }
        this.first = this.first.getNext();
        size--;
    }

    @Override
    public boolean isEmpty() {
        return this.first == null;
    }

    public Object getTop() {
        if (this.first == null) {
            System.out.println("No se puede obtener el tope de una pila vacía.");
            return -1;
        }
        return this.first.getValue();
    }

    public int getSize() {
        return size;
    }

    public int getCapacity() {
        return capacity;
    }
}