package org.Ejercicio6.a;

public interface ILimitedStack {
    void add(int a);

    void remove();

    boolean isEmpty();
}
